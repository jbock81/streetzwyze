# Digit

- `v::digit()`

This is similar to `v::alnum()`, but it doesn't allow a-Z.

***
See also:

  * [Alnum](Alnum.md)
  * [Alpha](Alpha.md)
  * [Vowel](Vowel.md)
  * [Consonant](Consonant.md)
