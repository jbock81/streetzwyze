# Negative

- `v::negative()`

Validates if a number is lower than zero

```php
v::numeric()->negative()->validate(-15); // true
```

***
See also:

  * [Positive](Positive.md)
