# Iterable

- `v::iterable()`

**Deprecated**: Use [IterableType](IterableType.md) instead.
