# Cnh

- `v::cnh()`

Validates a Brazillian driver's license.

```php
v::cnh()->validate('02650306461'); // true
```

***
See also:

  * [Cnpj](Cnpj.md)
  * [Cpf](Cpf.md)
